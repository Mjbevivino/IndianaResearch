# Indiana 92-County Economic Dashboard

County-level economic indicators for all 92 Indiana counties, sourced entirely from public government APIs.

## Data Sources

| Source | Data | Year | URL |
|--------|------|------|-----|
| U.S. Census ACS 5-Year | Income, poverty, education, labor force | 2022 | https://api.census.gov |
| BLS Local Area Unemployment Statistics | Unemployment rate, labor force | 2023 | https://www.bls.gov/lau/ |
| USDA ERS Rural-Urban Continuum Codes | Rural/metro classification | 2023 | https://www.ers.usda.gov |

## Indicators

- Median household income
- Poverty rate
- Unemployment rate (BLS LAUS official)
- Labor force participation rate
- Bachelor's degree attainment
- Median home value
- Total population
- Rural-Urban Continuum Code (1–9)

## Setup

```bash
# 1. Clone / download project
cd indiana-econ

# 2. Install dependencies
pip install -r requirements.txt

# 3. (Optional) Get free API keys for higher rate limits
#    Census: https://api.census.gov/data/key_signup.html
#    BLS:    https://data.bls.gov/registrationEngine/
export CENSUS_API_KEY=your_key_here
export BLS_API_KEY=your_key_here

# 4. Run the data pipeline (fetches all sources, builds master CSV)
python pipeline/build_dataset.py

# 5. Launch the dashboard
streamlit run app.py
```

## Pipeline

```
pipeline/
  fetch_census.py   — Census ACS 5-Year API → data/census_acs.csv
  fetch_bls.py      — BLS LAUS API          → data/bls_laus.csv
  fetch_usda.py     — USDA ERS direct DL    → data/usda_ers.csv
  build_dataset.py  — Merge all sources     → data/indiana_counties_master.csv
                                            → data/pipeline_manifest.json
```

Re-run pipeline to refresh data:
```bash
python pipeline/build_dataset.py --force   # ignore cache, re-fetch all
```

## Dashboard Features

- **Choropleth map** — any indicator across all 92 counties
- **Metro vs rural distribution** — histogram split by RUCC classification
- **Income vs unemployment scatter** — bubble size = population
- **County spotlight** — full indicator card for any selected county
- **Rankings table** — sortable by any indicator, downloadable CSV
- **Data dictionary** — field definitions, source citations, methodology

## Methodology Notes

- Census ACS 5-year estimates represent a rolling 2018–2022 average; more reliable for small counties than 1-year estimates.
- BLS LAUS unemployment rates are M13 (annual average) for 2023, the official labor statistics reference.
- RUCC codes 1–3 = metro, 4–6 = nonmetro urban/adjacent, 7–9 = rural. Derived `is_metro` and `is_rural` flags use this classification.
- No data imputation is applied. Missing values are shown as N/A.
- FIPS codes follow Census TIGER standard (state 18 = Indiana, 5-digit county codes).

## Reproducibility

All data is fetched from stable public government endpoints with documented API versions. The `pipeline_manifest.json` records fetch timestamps, source URLs, and variable definitions for each build.

## Version

v1.0 — Census ACS + BLS LAUS + USDA ERS  
Planned v2: BLS QCEW manufacturing/wage data, FRED economic indicators
